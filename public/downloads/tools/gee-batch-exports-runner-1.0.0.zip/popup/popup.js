const delayInput = document.querySelector('#delay');
const statusText = document.querySelector('#status');
const startButton = document.querySelector('#start');
const stopButton = document.querySelector('#stop');

function setStatus(message) {
  statusText.textContent = message;
}

async function getEarthEngineTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id || !tab.url || !tab.url.startsWith('https://code.earthengine.google.com/')) {
    throw new Error('Open Earth Engine Code Editor first.');
  }

  return tab;
}

async function runInActiveTab(func, args = []) {
  const tab = await getEarthEngineTab();
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func,
    args,
  });
  return result && result.result;
}

function batchRunGeeTasks(rawDelayMs) {
  const delayMs = Math.max(500, Number(rawDelayMs) || 1500);
  const dialogSelectors = [
    'ee-image-config-dialog',
    'ee-table-config-dialog',
    'ee-video-config-dialog',
    'ee-map-config-dialog',
  ];

  globalThis.__geeBatchExportsStopRequested = false;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function isVisible(element) {
    if (!element || element.disabled) return false;
    if (element.getAttribute && element.getAttribute('aria-disabled') === 'true') return false;
    const rect = element.getBoundingClientRect ? element.getBoundingClientRect() : null;
    if (rect && rect.width === 0 && rect.height === 0) return false;
    return true;
  }

  function deepQuerySelectorAll(selector, root = document) {
    const results = [];
    const queue = [root];
    const seen = new Set();

    while (queue.length) {
      const current = queue.shift();
      if (!current || seen.has(current)) continue;
      seen.add(current);

      if (current.querySelectorAll) {
        results.push(...current.querySelectorAll(selector));
        current.querySelectorAll('*').forEach((child) => {
          if (child.shadowRoot) queue.push(child.shadowRoot);
        });
      }
    }

    return results;
  }

  function getTaskRoots() {
    return deepQuerySelectorAll('ee-task-pane')
      .map((element) => element.shadowRoot)
      .filter(Boolean);
  }

  function getRunButtons() {
    const taskRoots = getTaskRoots();
    const roots = taskRoots.length ? taskRoots : [document];
    return roots
      .flatMap((root) => Array.from(root.querySelectorAll('.run-button')))
      .filter(isVisible);
  }

  function getDialogRoots() {
    return dialogSelectors
      .flatMap((selector) => deepQuerySelectorAll(selector))
      .flatMap((dialog) => [dialog, dialog.shadowRoot].filter(Boolean));
  }

  function getConfirmButtons() {
    const roots = getDialogRoots();
    const buttons = roots.flatMap((root) => deepQuerySelectorAll('.ok-button', root));
    return buttons.filter(isVisible);
  }

  async function waitForConfirmButton(timeoutMs = 10000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      const [button] = getConfirmButtons();
      if (button) return button;
      await sleep(250);
    }
    return null;
  }

  async function run() {
    let submitted = 0;
    let stoppedReason = 'No RUN buttons found.';

    while (!globalThis.__geeBatchExportsStopRequested) {
      const [runButton] = getRunButtons();
      if (!runButton) {
        stoppedReason = 'No more RUN buttons.';
        break;
      }

      runButton.click();
      const confirmButton = await waitForConfirmButton();
      if (!confirmButton) {
        stoppedReason = 'Confirmation dialog was not found.';
        break;
      }

      confirmButton.click();
      submitted += 1;
      await sleep(delayMs);
    }

    if (globalThis.__geeBatchExportsStopRequested) {
      stoppedReason = 'Stopped by user.';
    }

    return {
      submitted,
      stoppedReason,
      remainingRunButtons: getRunButtons().length,
    };
  }

  return run();
}

function stopGeeBatchTasks() {
  globalThis.__geeBatchExportsStopRequested = true;
  return { stopped: true };
}

function inspectGeeTasks() {
  function deepQuerySelectorAll(selector, root = document) {
    const results = [];
    const queue = [root];
    const seen = new Set();

    while (queue.length) {
      const current = queue.shift();
      if (!current || seen.has(current)) continue;
      seen.add(current);

      if (current.querySelectorAll) {
        results.push(...current.querySelectorAll(selector));
        current.querySelectorAll('*').forEach((child) => {
          if (child.shadowRoot) queue.push(child.shadowRoot);
        });
      }
    }

    return results;
  }

  const taskPane = deepQuerySelectorAll('ee-task-pane')[0];
  const runButtons = taskPane && taskPane.shadowRoot
    ? taskPane.shadowRoot.querySelectorAll('.run-button').length
    : 0;

  return {
    hasTaskPane: Boolean(taskPane),
    runButtons,
  };
}

startButton.addEventListener('click', async () => {
  try {
    startButton.disabled = true;
    setStatus('Running tasks...');
    const response = await runInActiveTab(batchRunGeeTasks, [Number(delayInput.value)]);
    setStatus(`${response.stoppedReason} Submitted ${response.submitted}. Remaining RUN buttons: ${response.remainingRunButtons}.`);
  } catch (error) {
    setStatus(error.message);
  } finally {
    startButton.disabled = false;
  }
});

stopButton.addEventListener('click', async () => {
  try {
    await runInActiveTab(stopGeeBatchTasks);
    setStatus('Stop requested.');
  } catch (error) {
    setStatus(error.message);
  }
});

runInActiveTab(inspectGeeTasks)
  .then((response) => {
    if (!response.hasTaskPane) {
      setStatus('Tasks pane not found. Open Earth Engine Code Editor and reload it.');
      return;
    }
    setStatus(`Ready. RUN buttons visible: ${response.runButtons}.`);
  })
  .catch((error) => setStatus(error.message));
